import { useState } from "react";

const pages = [
  {
    content: (
      <>
        <h1 style={{ fontSize: "2rem", textAlign: "center", marginBottom: "1rem" }}>
          Aujourd'hui, on célèbre un homme unique, un papa en or, un guitariste de coeur...
        </h1>
        <p style={{ textAlign: "center", fontSize: "1.2rem" }}>Prêt pour la surprise ?</p>
      </>
    ),
  },
  {
    content: (
      <>
        <h2 style={{ fontSize: "1.5rem", textAlign: "center", marginBottom: "1rem" }}>Énigme – L’Élu des étoiles</h2>
        <p>
          On m’appelle parfois le Grand Monarque, <br />
          Entre cristal cosmique et lumière opaque. <br />
          Je ne suis ni dieu, ni roi, ni fou, <br />
          Pourtant sur YouTube, on me connaît beaucoup. <br />
          Certains rient, d’autres croient, <br />
          Moi, je trace ma voie dans les lois de Gaïa. <br />
          Cherche mon nom dans l’espace infini, <br />
          Mon prénom est forêt, mon nom… devine qui ?
        </p>
      </>
    ),
  },
  {
    content: (
      <>
        <h2 style={{ fontSize: "1.5rem", textAlign: "center", marginBottom: "1rem" }}>À toi, mon Soley</h2>
        <p style={{ whiteSpace: "pre-line" }}>
          Depuis ce dix mars, sans prévenir, Tu es entré dans mon avenir.
          Un message, un regard, un instant, Et très vite sont venus les appels… longs, vibrants.
          Des heures à se parler sans voir le temps, Comme si nos âmes savaient depuis longtemps.
          Toi, le Lion de Douala, fier et vaillant, Moi, la Lionne aux terres d’océan,
          Liés par un symbole, un rugissement, Qui résonne entre nos deux continents.
          Entre Marseille et la Réunion, Nos pensées jouent à l’unisson.
          Comme un murmure doux du destin, Tu m’écris, je t’écris... en même temps, c’est pas rien.
          David Goggins et Sylvain Durif, On a ri fort, c’était pas fictif.
          Même les roux n’ont pas été épargnés, À deux, nos délires savent voyager.
          Tu es tombé sur moi, ou moi sur toi ? Peu importe, le cœur ne ment pas.
          Nos âmes s’attirent, nos corps le savent, Ce lien est fort, doux et brave.
          On s’écoute, on se comprend, Chaque mot devient un fondement.
          Tu respectes mes peurs, mes silences, Et je célèbre ta force, ta présence.
          Le 5 mai approche, et avec lui, Le frisson de te savoir ici.
          Plus près de moi, plus près du feu, Celui qu’on allume à deux, heureux.
          Alors aujourd’hui, je te célèbre, Toi, l’homme qui fait battre mon être.
          Bon anniversaire, mon Soley adoré, Que cette histoire ne cesse de vibrer.
        </p>
      </>
    ),
  },
  {
    content: <img src="/image1.jpg" alt="Bon Cadeau" style={{ maxWidth: "100%", borderRadius: "1rem" }} />,
  },
  {
    content: (
      <>
        <img src="/image2.jpg" alt="Fin du livre" style={{ maxWidth: "100%", borderRadius: "1rem" }} />
        <p style={{ fontSize: "1.2rem", textAlign: "center", fontStyle: "italic", marginTop: "1rem" }}>
          Ce n'est que le début... Bon Anniversaire mon Soley. Tu es le cœur préféré d'une Lionne à l'autre bout du monde.
        </p>
      </>
    ),
  },
];

export default function App() {
  const [pageIndex, setPageIndex] = useState(0);
  const nextPage = () => setPageIndex((prev) => (prev + 1 < pages.length ? prev + 1 : prev));
  const restart = () => setPageIndex(0);

  return (
    <div style={{ minHeight: "100vh", padding: "2rem", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
      <audio autoPlay loop src="/running-to-you-guitar.mp3" />
      <div style={{ background: "#fff", padding: "2rem", borderRadius: "1rem", boxShadow: "0 10px 30px rgba(0,0,0,0.1)", maxWidth: "800px", width: "100%" }}>
        {pages[pageIndex].content}
      </div>
      <div style={{ marginTop: "1.5rem" }}>
        {pageIndex < pages.length - 1 ? (
          <button onClick={nextPage} style={{ padding: "0.5rem 1rem", fontSize: "1rem", borderRadius: "0.5rem", background: "#f9a825", color: "white", border: "none" }}>
            Page suivante
          </button>
        ) : (
          <button onClick={restart} style={{ padding: "0.5rem 1rem", fontSize: "1rem", borderRadius: "0.5rem", background: "#00bfa5", color: "white", border: "none" }}>
            Recommencer
          </button>
        )}
      </div>
    </div>
  );
}